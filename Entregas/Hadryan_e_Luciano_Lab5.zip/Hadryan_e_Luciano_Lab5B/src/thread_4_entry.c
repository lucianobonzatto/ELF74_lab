#include "thread_4.h"

#include "globals.h"

/* thread_4 entry function */
void thread_4_entry(void)
{
    thread_3_and_4_entry(4);
}
