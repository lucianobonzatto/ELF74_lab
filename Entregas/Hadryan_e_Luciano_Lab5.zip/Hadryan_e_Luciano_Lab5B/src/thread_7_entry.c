#include "thread_7.h"

#include "globals.h"

/* thread_7 entry function */
void thread_7_entry(void)
{
    thread_6_and_7_entry(7);
}
