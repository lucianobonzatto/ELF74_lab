#include "thread_6.h"

#include "globals.h"

/* thread_6 entry function */
void thread_6_entry(void)
{
    thread_6_and_7_entry(6);
}
