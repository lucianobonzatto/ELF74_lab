#include "thread_3.h"

#include "globals.h"

/* thread_3 entry function */
void thread_3_entry(void)
{
    thread_3_and_4_entry(3);
}
